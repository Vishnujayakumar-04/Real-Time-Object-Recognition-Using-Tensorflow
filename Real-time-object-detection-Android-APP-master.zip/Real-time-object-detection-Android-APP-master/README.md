# Real-time-object-detection-Android-APP
A Real Time Object Detection Android APP using TensorFlow Lite
